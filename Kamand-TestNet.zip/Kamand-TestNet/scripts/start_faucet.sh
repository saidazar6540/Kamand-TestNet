#!/bin/sh
echo "Starting Faucet..."
node /faucet/app.js
