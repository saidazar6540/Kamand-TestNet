#!/bin/sh
echo "Starting Explorer..."
node /explorer/server.js
