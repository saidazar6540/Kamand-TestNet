#!/bin/sh
echo "Starting Fullnode..."
tail -f /dev/null
