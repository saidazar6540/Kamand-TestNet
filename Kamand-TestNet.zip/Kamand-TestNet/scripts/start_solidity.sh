#!/bin/sh
echo "Starting Solidity Node..."
tail -f /dev/null
