KamandNet local chain (fullnode, solidity, explorer, faucet)
Docker Compose network layout for Railway / Hubit
