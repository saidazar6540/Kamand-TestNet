#!/bin/sh
echo "Solidity OK"
exit 0