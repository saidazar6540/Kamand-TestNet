#!/bin/sh
echo "Fullnode OK"
exit 0
