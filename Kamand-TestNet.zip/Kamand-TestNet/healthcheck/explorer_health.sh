#!/bin/sh
echo "Explorer OK"
exit 0